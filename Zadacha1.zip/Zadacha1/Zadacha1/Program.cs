﻿//Задача 2

//string s_a = Console.ReadLine();
//string s_b=Console.ReadLine();

//int a= int.Parse(s_a);
//int b= int.Parse(s_b);


//if (a > b)
//{
// Console.WriteLine(a);
//   Console.WriteLine("a Больше");

//}
//else

//{
//Console.WriteLine(b);
//  Console.WriteLine("b Больше");
//}

//Задача 1

//int ch, a;
//a = 5;
//int ch = 45;

//Console.WriteLine(a * (ch * (-1)));

//Задача 3

//string s_a = Console.ReadLine();
//string s_b = Console.ReadLine();
//string s_c = Console.ReadLine();

//int a = int.Parse(s_a);
//int b= int.Parse(s_b);
//int c = int.Parse(s_c);

//if (a > b) ;
//{
//Console.WriteLine(a);
//  Console.WriteLine("a меньше");

//}


//else 
//{ 
//Console.WriteLine(b);
//Console.WriteLine("b больше ");

//}

// if (b > c) ;


// Задача 4


string s_a = Console.ReadLine();
int a = int.Parse(s_a);

 Console.WriteLine((-1)* a);
Console.WriteLine(0.5*a);



















